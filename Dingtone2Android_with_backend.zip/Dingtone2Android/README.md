# Dingtone 2 — Android starter project

This is a small native Android starter app with a home screen, temporary-number information screen, and a dialer handoff. It does **not** provide real phone numbers, receive SMS, or make VoIP calls yet.

## Open and build
1. Install Android Studio (stable) and its Android SDK.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `Dingtone2Android` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and the matching build tools.
5. To test, connect an Android phone with USB debugging enabled or start an emulator, then press **Run**.
6. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio will show a notification with **locate**; the debug APK is typically under `app/build/outputs/apk/debug/app-debug.apk`.

## To add real temporary numbers and SMS
- Choose a legitimate phone-number/SMS provider that supports number inventory, number assignment, and inbound SMS in your target countries.
- Create a backend service to keep provider API credentials secret. The Android app should call your backend, not embed secret API keys.
- Add authentication, rate limits, abuse prevention, consent/privacy disclosures, and account-level number ownership.
- Implement number search, rental/assignment, renewal/expiry, inbound SMS webhooks, and a secure inbox.
- Check the provider's terms and the rules of services where users may use the numbers. Some services block VoIP/shared numbers.

## To add internet calling
- Choose a licensed SIP/VoIP provider and its Android SDK or supported SIP stack.
- Configure user authentication and short-lived credentials through your backend.
- Add call permissions and the provider's call UI, connection states, error handling, and emergency-call disclaimers.
- Calls to ordinary phone numbers generally are not free; pricing depends on the provider and destination.

## Important
This project uses the name “Dingtone 2” as a requested working title. Before publishing, check trademark/name availability and use original branding and assets. It is a starter project, not a clone of Dingtone's proprietary app or source code.


## Backend prototype added
See the `backend/` folder for an Express/Twilio backend scaffold with a Voice SDK token endpoint, number search endpoint, and inbound SMS webhook placeholder. Read `backend/README.md` carefully: demo authentication is unsafe for production and SMS is not persisted yet.
