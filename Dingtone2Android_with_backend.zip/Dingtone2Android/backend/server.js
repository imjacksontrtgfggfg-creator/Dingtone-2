require("dotenv").config();
const express = require("express");
const twilio = require("twilio");

const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const requiredEnv = [
  "TWILIO_ACCOUNT_SID",
  "TWILIO_API_KEY_SID",
  "TWILIO_API_KEY_SECRET",
  "TWILIO_TWIML_APP_SID",
  "PUBLIC_BASE_URL"
];

function ensureConfigured(req, res, next) {
  const missing = requiredEnv.filter((key) => !process.env[key]);
  if (missing.length) {
    return res.status(503).json({
      error: "Provider not configured",
      missing
    });
  }
  next();
}

// DEMO AUTH ONLY: replace with real user authentication before deployment.
// For example, verify Firebase ID tokens or your own signed access tokens.
function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  if (header !== "Bearer dev-only-change-me") {
    return res.status(401).json({ error: "Authentication required" });
  }
  req.user = { id: "demo-user" };
  next();
}

app.get("/health", (req, res) => res.json({ ok: true, service: "dingtone2-backend" }));

// Return a short-lived Voice SDK access token.
// Keep provider secrets on this server, never in the APK.
app.post("/api/voice/token", ensureConfigured, requireAuth, (req, res) => {
  const identity = `user_${String(req.user.id).replace(/[^a-zA-Z0-9_]/g, "_")}`;
  const AccessToken = twilio.jwt.AccessToken;
  const VoiceGrant = AccessToken.VoiceGrant;

  const token = new AccessToken(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_API_KEY_SID,
    process.env.TWILIO_API_KEY_SECRET,
    { identity, ttl: 3600 }
  );

  token.addGrant(new VoiceGrant({
    outgoingApplicationSid: process.env.TWILIO_TWIML_APP_SID,
    incomingAllow: true
  }));

  res.json({ identity, token: token.toJwt(), expiresInSeconds: 3600 });
});

// Twilio Voice requests this URL for an outgoing PSTN call.
// Validate Twilio request signatures before production deployment.
// Add destination allowlists, rate limits, abuse checks, and budget limits.
app.post("/voice/outbound", ensureConfigured, (req, res) => {
  const to = String(req.body.To || "").trim();
  if (!/^\+[1-9]\d{6,14}$/.test(to)) {
    return res.status(400).type("text/plain").send("Destination must be E.164 format.");
  }

  const twiml = new twilio.twiml.VoiceResponse();
  const dial = twiml.dial({
    callerId: process.env.TWILIO_PHONE_NUMBER
  });
  dial.number(to);
  res.type("text/xml").send(twiml.toString());
});

// Search available numbers. This searches provider inventory; it does not
// automatically make the number temporary or guarantee inbound SMS support.
app.get("/api/numbers/search", ensureConfigured, requireAuth, async (req, res) => {
  const country = String(req.query.country || "US").toUpperCase();
  if (!/^[A-Z]{2}$/.test(country)) {
    return res.status(400).json({ error: "country must be a two-letter country code" });
  }

  try {
    const client = twilio(
      process.env.TWILIO_API_KEY_SID,
      process.env.TWILIO_API_KEY_SECRET,
      { accountSid: process.env.TWILIO_ACCOUNT_SID }
    );
    const numbers = await client.availablePhoneNumbers(country).local.list({
      smsEnabled: true,
      voiceEnabled: true,
      limit: 10
    });
    res.json({
      country,
      numbers: numbers.map(n => ({
        phoneNumber: n.phoneNumber,
        locality: n.locality,
        region: n.region,
        capabilities: n.capabilities
      }))
    });
  } catch (err) {
    console.error("Number search failed:", err.message);
    res.status(502).json({ error: "Number search failed. Check provider account and country availability." });
  }
});

// Inbound SMS webhook starter. Configure a provider number to POST here.
// Production TODO: validate provider signature, persist the message to a database,
// associate it with the number's owner, and notify only that owner.
app.post("/webhooks/sms/inbound", (req, res) => {
  const message = {
    from: req.body.From || "",
    to: req.body.To || "",
    body: req.body.Body || "",
    receivedAt: new Date().toISOString()
  };
  console.log("Inbound SMS webhook received (demo; not persisted):", {
    from: message.from, to: message.to, receivedAt: message.receivedAt
  });
  res.type("text/xml").send("<Response></Response>");
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Dingtone 2 backend listening on port ${port}`));
