# Dingtone 2 backend starter

This is a prototype scaffold for Twilio-based voice token issuance and phone-number search. It is not production-ready and does not yet purchase/rent numbers, persist SMS, or implement real user accounts.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and enter your Twilio credentials and TwiML App SID.
3. Run `npm install`, then `npm start`.
4. Check `http://localhost:3000/health`.

## Test the demo-protected endpoints
The placeholder auth token is `dev-only-change-me`. It is intentionally a development-only shortcut:
- `POST /api/voice/token` with `Authorization: Bearer dev-only-change-me`
- `GET /api/numbers/search?country=US` with the same header

Do not deploy with this demo authentication. Replace `requireAuth` with proper user authentication before exposing the service.

## Provider setup still required
- Create a Twilio project and provision a phone number with the capabilities you need.
- Create a TwiML App and set its Voice Request URL to `https://YOUR_PUBLIC_HTTPS_HOST/voice/outbound`.
- Set the number's incoming SMS webhook to `https://YOUR_PUBLIC_HTTPS_HOST/webhooks/sms/inbound`.
- Configure HTTPS. For local webhook testing, use a secure tunnel.
- Verify webhook signatures before production.
- Add a database for accounts, number ownership, rental expiration, SMS inbox, call logs, usage and audit records.
- Add a scheduled task to expire/release numbers and delete data under your retention policy.
- Add spend limits, rate limiting, country/destination restrictions, fraud prevention, consent, and privacy/legal disclosures.

## Android integration
The current Android project is intentionally provider-independent and still uses the system dialer. For in-app internet calling, add Twilio's official Voice Android SDK and use the token returned by `/api/voice/token`. Follow the official quickstart for SDK initialization, outgoing calls, incoming push notifications, and Firebase Cloud Messaging:
https://www.twilio.com/docs/voice/sdks/android/get-started

Never embed Twilio Auth Tokens, API secrets, or unrestricted credentials in the APK. Use short-lived Voice SDK tokens from your authenticated backend.
