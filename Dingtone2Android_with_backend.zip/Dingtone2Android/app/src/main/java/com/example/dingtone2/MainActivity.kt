package com.example.dingtone2

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val blue = Color.rgb(36, 91, 219)
    private val ink = Color.rgb(25, 35, 58)
    private val muted = Color.rgb(103, 116, 140)
    private val pale = Color.rgb(241, 245, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
    }

    private fun button(text: String, action: () -> Unit, primary: Boolean = false): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 15f
            setTextColor(if (primary) Color.WHITE else blue)
            if (primary) setBackgroundColor(blue)
            setOnClickListener { action() }
        }
    }

    private fun base(title: String, subtitle: String) {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(20), dp(22), dp(20), dp(16))
        }
        page.addView(label("Dingtone 2", 14f, blue, true))
        page.addView(label(title, 28f, ink, true))
        page.addView(label(subtitle, 14f, muted))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(8))
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        nav.addView(button("Home") { showHome() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(button("Numbers") { showNumbers() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(button("Call") { showCall() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        page.addView(nav)
        setContentView(page)
    }

    private fun addCard(title: String, description: String, actionLabel: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(pale)
        }
        card.addView(label(title, 18f, ink, true))
        card.addView(label(description, 14f, muted))
        card.addView(button(actionLabel, action, true))
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = dp(14)
        content.addView(card, params)
    }

    private fun showHome() {
        base("Your calls, one place", "A starter app for internet calling and virtual numbers.")
        addCard("Get a temporary number", "Browse numbers from a supported SMS/number provider. Provider integration is not configured yet.", "Browse numbers") { showNumbers() }
        addCard("Make a call", "Open your phone's dialer, or connect a VoIP provider for in-app calling.", "Open dial pad") { showCall() }
        addCard("Credits & account", "This demo does not charge you or store payment information.", "View account") {
            Toast.makeText(this, "Account and credit features need a backend.", Toast.LENGTH_LONG).show()
        }
        content.addView(label("DEMO MODE • No real number or SMS service is connected", 12f, muted))
    }

    private fun showNumbers() {
        base("Temporary numbers", "Real numbers must come from a provider; this demo does not generate them.")
        addCard("Choose a country", "When connected, this area can list the countries and numbers the provider supports.", "See integration steps") {
            Toast.makeText(this, "Connect a number/SMS API and a backend first.", Toast.LENGTH_LONG).show()
        }
        addCard("Receive SMS", "Incoming SMS can be displayed only if your provider supports inbound messaging and the number is assigned to your account.", "How it works") {
            Toast.makeText(this, "SMS delivery depends on the provider and sender restrictions.", Toast.LENGTH_LONG).show()
        }
        content.addView(label("Important: many services, including some verification systems, block VoIP or shared temporary numbers.", 13f, muted))
    }

    private fun showCall() {
        base("Make a call", "Starter dialer: this opens the Android phone app.")
        val field = android.widget.EditText(this).apply {
            hint = "Enter phone number"
            textSize = 20f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        content.addView(field, LinearLayout.LayoutParams(-1, -2))
        content.addView(button("Call using phone dialer", {
            val number = field.text.toString().trim()
            if (number.isBlank()) {
                Toast.makeText(this, "Enter a phone number first.", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
                } catch (_: Exception) {
                    Toast.makeText(this, "No compatible dialer app found.", Toast.LENGTH_LONG).show()
                }
            }
        }, true))
        content.addView(label("This uses your phone/SIM dialer and may incur carrier charges. It is not VoIP calling yet.", 13f, muted))
        content.addView(button("VoIP integration notes") {
            Toast.makeText(this, "For internet calls, integrate a licensed SIP/VoIP SDK and provider credentials on a secure backend.", Toast.LENGTH_LONG).show()
        })
    }
}
